﻿namespace GroceryStoreAPI.Resources
{
    //Resource returned after a sucessful request on the customer data
    public class CustomerResource
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
