﻿using System.ComponentModel.DataAnnotations;

namespace GroceryStoreAPI.Resources
{
    //Resource recieved in the event of a Put or Post request
    public class SaveCustomerResource
    {
        [Required]
        [MaxLength(80)]
        public string Name { get; set; }
    }
}
