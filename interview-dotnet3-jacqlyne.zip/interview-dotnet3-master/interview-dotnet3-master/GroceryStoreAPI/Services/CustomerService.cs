﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GroceryStoreAPI.Domain.Services;
using GroceryStoreAPI.Domain.Models;
using GroceryStoreAPI.Domain.Repositories;
using GroceryStoreAPI.Domain.Services.Responses;

namespace GroceryStoreAPI.Services
{
    //Service which enables access to the API's craeted for handling customer data
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CustomerService(ICustomerRepository customerRepository, IUnitOfWork unitOfWork)
        {
            _customerRepository = customerRepository;
            _unitOfWork = unitOfWork;
        }

        /// <summary>
        /// Lists all customers.
        /// </summary>
        /// <returns>List of customers.</returns>
        public async Task<IEnumerable<StoreCustomer>> ListAsync() => await _customerRepository.ListAsync();

        /// <summary>
        /// Find a given customer according to an identifier.
        /// </summary>
        /// <param name="id">Customer identifier.</param>
        /// <returns>Response.</returns>
        public async Task<CustomerResponse> FindByIdAsync(int id)
        {
            var existingCustomer = await _customerRepository.FindByIdAsync(id);

            if (existingCustomer == null)
                return new CustomerResponse("Customer not found.");

            return new CustomerResponse(existingCustomer);
        }

        /// <summary>
        /// Save a new customer.
        /// </summary>
        /// <param name="resource">Customer data.</param>
        /// <returns>Response.</returns>
        public async Task<CustomerResponse> SaveAsync(StoreCustomer customer)
        {
            try
            {
                await _customerRepository.AddAsync(customer);
                await _unitOfWork.CompleteAsync();

                return new CustomerResponse(customer);
            }
            catch (Exception ex)
            {
                return new CustomerResponse($"An error occurred when saving the customer: {ex.Message}");
            }
        }

        /// <summary>
        /// Updates an existing customer according to an identifier.
        /// </summary>
        /// <param name="id">Customer identifier.</param>
        /// <param name="resource">Updated customer data.</param>
        /// <returns>Response.</returns>
        public async Task<CustomerResponse> UpdateAsync(int id, StoreCustomer customer)
        {
            var existingCustomer = await _customerRepository.FindByIdAsync(id);

            if (existingCustomer == null)
                return new CustomerResponse("Customer not found.");

            existingCustomer.Name = customer.Name;

            try
            {
                await _unitOfWork.CompleteAsync();

                return new CustomerResponse(existingCustomer);
            }
            catch (Exception ex)
            {
                return new CustomerResponse($"An error occurred when updating the customer: {ex.Message}");
            }
        }

        /// <summary>
        /// Deletes a given customer according to an identifier.
        /// </summary>
        /// <param name="id">Customer identifier.</param>
        /// <returns>Response.</returns>
        public async Task<CustomerResponse> DeleteAsync(int id)
        {
            var existingCustomer = await _customerRepository.FindByIdAsync(id);

            if (existingCustomer == null)
                return new CustomerResponse("Customer not found.");

            try
            {
                _customerRepository.Remove(existingCustomer);
                await _unitOfWork.CompleteAsync();

                return new CustomerResponse(existingCustomer);
            }
            catch (Exception ex)
            {
                return new CustomerResponse($"An error occurred when deleting the customer: {ex.Message}");
            }
        }
    }
}
