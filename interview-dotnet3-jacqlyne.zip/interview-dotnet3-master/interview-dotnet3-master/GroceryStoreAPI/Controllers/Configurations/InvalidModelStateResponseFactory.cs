﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using GroceryStoreAPI.Resources;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace GroceryStoreAPI.Controllers.Configurations
{
    //Custon error response factory for invalid model state
    public class InvalidModelStateResponseFactory
    {
        public static IActionResult ProduceErrorResponse(ActionContext context) {
            var errors = GetErrorMessages(context.ModelState);

            var response = new ErrorResource(messages: errors); 
            return new BadRequestObjectResult(response); 
        }

        public static List<string> GetErrorMessages(ModelStateDictionary dictionary)
        {
            return dictionary.SelectMany(m => m.Value.Errors)
                             .Select(m => m.ErrorMessage)
                             .ToList();
        }
    }
}
