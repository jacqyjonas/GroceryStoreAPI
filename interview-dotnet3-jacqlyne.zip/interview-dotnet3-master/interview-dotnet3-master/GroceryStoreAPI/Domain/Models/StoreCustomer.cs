﻿using System.Collections.Generic;

namespace GroceryStoreAPI.Domain.Models
{
    public class Customers
    {
        public List<StoreCustomer> customers;
    }

    //Customer Data Model
    public class StoreCustomer
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
