﻿using GroceryStoreAPI.Domain.Models;

namespace GroceryStoreAPI.Domain.Services.Responses
{
    public class CustomerResponse : BaseResponse<StoreCustomer>
    {
        /// <summary>
        /// Creates a success response.
        /// </summary>
        /// <param name="customer">Saved customer.</param>
        /// <returns>Response.</returns>
        public CustomerResponse(StoreCustomer customer) : base(customer)
        { }

        /// <summary>
        /// Creates am error response.
        /// </summary>
        /// <param name="message">Error message.</param>
        /// <returns>Response.</returns>
        public CustomerResponse(string message) : base(message)
        { }
    }
}
