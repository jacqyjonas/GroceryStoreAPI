﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStoreAPI.Domain.Models;
using GroceryStoreAPI.Domain.Services.Responses;

namespace GroceryStoreAPI.Domain.Services
{
    public interface ICustomerService
    {
        Task<IEnumerable<StoreCustomer>> ListAsync();
        Task<CustomerResponse> FindByIdAsync(int id);
        Task<CustomerResponse> SaveAsync(StoreCustomer customer);
        Task<CustomerResponse> UpdateAsync(int id, StoreCustomer customer);
        Task<CustomerResponse> DeleteAsync(int id);
    }
}
