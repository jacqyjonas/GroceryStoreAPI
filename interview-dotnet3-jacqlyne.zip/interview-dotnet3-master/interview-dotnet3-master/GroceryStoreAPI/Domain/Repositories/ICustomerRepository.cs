﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStoreAPI.Domain.Models;

namespace GroceryStoreAPI.Domain.Repositories
{
    public interface ICustomerRepository
    {
        Task<IEnumerable<StoreCustomer>> ListAsync();
        Task AddAsync(StoreCustomer customer);
        Task<StoreCustomer> FindByIdAsync(int id);
        void Update(StoreCustomer custome);
        void Remove(StoreCustomer customer);
    }
}
