﻿using System.Threading.Tasks;

namespace GroceryStoreAPI.Domain.Repositories
{
    public interface IUnitOfWork
    {
        Task CompleteAsync();
    }
}
