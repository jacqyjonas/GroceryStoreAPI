﻿using System.Threading.Tasks;
using GroceryStoreAPI.DataManagement.Contexts;
using GroceryStoreAPI.Domain.Repositories;

namespace GroceryStoreAPI.DataManagement.Repositories
{
    //Single DB context class for all repository trasactions
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _context;

        public UnitOfWork(AppDbContext context)
        {
            _context = context;
        }

        public async Task CompleteAsync() => await _context.SaveChangesAsync();
    }
}
