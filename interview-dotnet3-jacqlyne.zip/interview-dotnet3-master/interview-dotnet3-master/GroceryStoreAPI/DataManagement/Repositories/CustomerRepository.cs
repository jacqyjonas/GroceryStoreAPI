﻿using System.Collections.Generic;
using System.Threading.Tasks;
using GroceryStoreAPI.Domain.Models;
using GroceryStoreAPI.Domain.Repositories;
using GroceryStoreAPI.DataManagement.Contexts;
using Microsoft.EntityFrameworkCore;

namespace GroceryStoreAPI.DataManagement.Repositories
{
    //Abstract layer beteen customr data access and business logic
    public class CustomerRepository : BaseRepository, ICustomerRepository
    {
        public CustomerRepository(AppDbContext context) : base(context) { }

        public async Task<IEnumerable<StoreCustomer>> ListAsync()
        {
            return await _context.Customers
                                 .AsNoTracking()
                                 .ToListAsync();
        }

        public async Task<StoreCustomer> FindByIdAsync(int id) => await _context.Customers.FindAsync(id);

        public async Task AddAsync(StoreCustomer customer) => await _context.Customers.AddAsync(customer);        

        public void Update(StoreCustomer customer) => _context.Customers.Update(customer);

        public void Remove(StoreCustomer customer) => _context.Customers.Remove(customer);
    }
}
