﻿using System.Reflection;
using Microsoft.EntityFrameworkCore;
using GroceryStoreAPI.Domain.Models;
using System.IO;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace GroceryStoreAPI.DataManagement.Contexts
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<StoreCustomer> Customers { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }

        //Load data from the json file
        public async Task SeedTestData()
        {            
            var customers = new List<StoreCustomer>();
            using (StreamReader r = new StreamReader(Path.Combine(Directory.GetCurrentDirectory(), "database.json")))
            {
                string json = r.ReadToEnd();
                customers = JsonConvert.DeserializeObject<Customers>(json).customers;
            }

            Customers.AddRange(customers);
            await SaveChangesAsync();
        }
    }
}
