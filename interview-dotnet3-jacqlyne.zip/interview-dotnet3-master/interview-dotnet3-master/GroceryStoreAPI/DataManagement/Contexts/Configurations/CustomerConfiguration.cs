﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using GroceryStoreAPI.Domain.Models;

namespace GroceryStoreAPI.DataManagement.Contexts.Configurations
{
    public class CustomerConfiguration : IEntityTypeConfiguration<StoreCustomer>
    {
        //Customer data configuration
        public void Configure(EntityTypeBuilder<StoreCustomer> builder)
        {
            builder.ToTable("Customers");
            builder.HasKey(p => p.Id);
            builder.Property(p => p.Id).IsRequired().ValueGeneratedOnAdd();
            builder.Property(p => p.Name).IsRequired().HasMaxLength(80);
        }
    }
}
