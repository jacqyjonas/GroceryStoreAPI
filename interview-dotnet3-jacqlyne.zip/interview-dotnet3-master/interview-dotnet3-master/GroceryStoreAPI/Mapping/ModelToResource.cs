﻿using AutoMapper;
using GroceryStoreAPI.Domain.Models;
using GroceryStoreAPI.Resources;

namespace GroceryStoreAPI.Mapping
{
    public class ModelToResource : Profile
    {
        //Map data models to the data resource returned after a sucessful request
        public ModelToResource()
        {
            CreateMap<StoreCustomer, CustomerResource>();
        }
    }
}
