﻿using AutoMapper;
using GroceryStoreAPI.Domain.Models;
using GroceryStoreAPI.Resources;

namespace GroceryStoreAPI.Mapping
{
    public class ResourceToModel : Profile
    {
        //Map data resource to the data model during a Post or Put request
        public ResourceToModel()
        {
            CreateMap<SaveCustomerResource, StoreCustomer>();
        }
    }
}
