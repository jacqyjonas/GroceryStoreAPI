using AutoMapper;
using GroceryStoreAPI.Controllers;
using GroceryStoreAPI.DataManagement.Contexts;
using GroceryStoreAPI.Domain.Services;
using GroceryStoreAPI.Domain.Repositories;
using System.Threading.Tasks;
using Xunit;
using GroceryStoreAPI.Services;
using Microsoft.EntityFrameworkCore;
using GroceryStoreAPI.DataManagement.Repositories;
using GroceryStoreAPI.Mapping;
using Microsoft.AspNetCore.Mvc;
using GroceryStoreAPI.Resources;
using System.Linq;

namespace GroceryStoreAPITests
{
    public class GroceryStoreUnitTests
    {
        private readonly ICustomerService _customerService;
        private readonly CustomerController _customerContoller;
        private readonly ICustomerRepository _customerRepo;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly AppDbContext _appDbContext;

        //Set up the application
        public GroceryStoreUnitTests()
        {
            //Arrange
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseInMemoryDatabase("memory");
            _appDbContext = new AppDbContext(optionsBuilder.Options);

            _customerRepo = new CustomerRepository(_appDbContext);
            _unitOfWork = new UnitOfWork(_appDbContext);

            //auto mapper configuration
            var mapConfig = new MapperConfiguration(cfg =>
            {
                cfg.AddProfile(new ModelToResource());
                cfg.AddProfile(new ResourceToModel());
            });
            _mapper = mapConfig.CreateMapper();

            _customerService = new CustomerService(_customerRepo, _unitOfWork);
            _customerContoller = new CustomerController(_customerService, _mapper);            
        }

        //Get and verify the total number of customers
        [Fact]
        public async Task CanGetAllCustomers()
        {
            //Act
            if(_appDbContext.Customers.Count() == 0)
                await _appDbContext.SeedTestData();

            var response = await _customerContoller.ListAsync();

            //Assert
            Assert.NotNull(response);

            int currentCount = response.Count();

            //Count will be in this range depeding on order of async test method execution
            Assert.True(currentCount >= 2 && currentCount <= 4);
        }

        //Get an existing customer and verify the right customer was retrived
        [Fact]
        public async Task CanGetExistingCustomer()
        {
            //Act
            if (_appDbContext.Customers.Count() == 0)
                await _appDbContext.SeedTestData();
            var response = await _customerContoller.GetAsync(1);

            //Assert
            var okResult = response as OkObjectResult;
            Assert.NotNull(response);
            
            var customer = okResult.Value as CustomerResource;

            Assert.Equal(expected: "Bob", actual: customer.Name);
        }

        //Add a customer, verify the right customer was added and verify the customer count
        [Fact]
        public async Task CanSaveNewCustomer()
        {
            //Act
            if (_appDbContext.Customers.Count() == 0)
                await _appDbContext.SeedTestData();

            SaveCustomerResource update = new SaveCustomerResource { Name = "Kevin" };

            var getAllBeforeAddResponse = await _customerContoller.ListAsync();
            var saveResponse = await _customerContoller.PostAsync(update);
            var getAllAfterAddresponse = await _customerContoller.ListAsync();

            //Assert
            var okResult = saveResponse as OkObjectResult;
            var customer = okResult.Value as CustomerResource;

            Assert.NotNull(getAllBeforeAddResponse);
            Assert.NotNull(saveResponse);
            Assert.NotNull(getAllAfterAddresponse);

            Assert.Equal(expected: "Kevin", actual: customer.Name);
            Assert.Equal(expected: getAllBeforeAddResponse.Count() + 1, actual: getAllAfterAddresponse.Count());
        }

        //Update a customer and verify the updated data
        [Fact]
        public async Task CanUpdateExistingCustomer()
        {
            //Act
            if (_appDbContext.Customers.Count() == 0)
                await _appDbContext.SeedTestData();

            SaveCustomerResource update = new SaveCustomerResource { Name = "Jacqlyne" };

            var response = await _customerContoller.PutAsync(2, update);

            //Assert
            var okResult = response as OkObjectResult;
            Assert.NotNull(response);

            var customer = okResult.Value as CustomerResource;

            Assert.Equal(expected: "Jacqlyne", actual: customer.Name);
        }

        //Delete a customer, verify the right customer was deleted and verify the customer count
        [Fact]
        public async Task CanDeleteExistingCustomer()
        {
            //Act
            if (_appDbContext.Customers.Count() == 0)
                await _appDbContext.SeedTestData();

            var getAllBeforeDeleteResponse = await _customerContoller.ListAsync();
            var deleteResponse = await _customerContoller.DeleteAsync(3);
            var getAllAfterDeleteResponse = await _customerContoller.ListAsync();

            //Assert           
            var okResult = deleteResponse as OkObjectResult;
            var customer = okResult.Value as CustomerResource;

            Assert.NotNull(getAllBeforeDeleteResponse);
            Assert.NotNull(deleteResponse);
            Assert.NotNull(getAllAfterDeleteResponse);

            Assert.Equal(expected: "Joe", actual: customer.Name);
            Assert.Equal(expected: getAllBeforeDeleteResponse.Count() - 1, actual: getAllAfterDeleteResponse.Count());
        }
    }
}
